# TRE Auto Select — MVP
Prototype indépendant du marketplace.

Fonctions incluses:
- Accueil + moteur de recherche marque/modèle, carburant, transmission, année, vérification
- Profils vendeurs (maquette)
- Création d'annonce avec VIN/châssis + carte grise obligatoires
- Jusqu'à 30 photos côté interface
- Statuts: disponible, transit, formalités douanières, arrivée en Tunisie, livrée
- Validation admin avant publication
- Multilingue FR/EN/DE/AR
- Base locale de démonstration

À transformer pour production:
1. Backend + base PostgreSQL/Supabase
2. Authentification et rôles acheteur/vendeur/admin
3. Stockage photos sécurisé (S3/Supabase Storage)
4. Expiration automatique à 35 jours via job serveur
5. Stripe Checkout/Webhooks pour les 30 €
6. Vérification VIN/documents avec workflow admin
7. Protection des données personnelles, logs, suppression/export
8. Conditions d'utilisation et conformité juridique FCR avant mise en ligne.
